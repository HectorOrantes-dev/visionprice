import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../../core/router/app_router.dart';

class ArquitectoGestionProyectosPage extends StatefulWidget {
  const ArquitectoGestionProyectosPage({super.key});

  @override
  State<ArquitectoGestionProyectosPage> createState() => _ArquitectoGestionProyectosPageState();
}

class _ArquitectoGestionProyectosPageState extends State<ArquitectoGestionProyectosPage> {
  String _searchQuery = '';

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Gestión de Proyectos',
          style: TextStyle(color: Colors.black, fontSize: 16, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.folder_outlined, color: Colors.blue),
                ),
                const SizedBox(width: 16),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Mis proyectos',
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '4 activos - Arq. Sánchez',
                        style: TextStyle(color: Colors.grey, fontSize: 14),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () {
                    context.push(AppRoutes.voiceRecord);
                  },
                  icon: const Icon(Icons.add, color: Colors.blue),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: TextField(
              onChanged: (value) {
                setState(() {
                  _searchQuery = value.toLowerCase();
                });
              },
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search, color: Colors.grey),
                hintText: 'Buscar proyecto...',
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.3)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide(color: Colors.grey.withOpacity(0.3)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: const BorderSide(color: Colors.blue),
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                if ('torre corporativa polanco'.contains(_searchQuery))
                  _buildProjectCard(
                    title: 'Torre Corporativa Polanco',
                    statusBadge: 'Alerta',
                    statusBadgeBg: Colors.red.withOpacity(0.1),
                    statusBadgeColor: Colors.red,
                    subtitle: 'Polanco · 3 contratistas · 18 partidas',
                    progressValue: 0.8,
                    progressColor: Colors.red,
                    bottomLeftText: '\$1.4M',
                    bottomCenterBadge: 'En validación',
                    bottomCenterBadgeBg: Colors.orange.withOpacity(0.1),
                    bottomCenterBadgeColor: Colors.orange[800]!,
                    bottomRightText: 'Desviación +18%',
                  ),
                if ('torre corporativa polanco'.contains(_searchQuery))
                  const SizedBox(height: 16),
                if ('residencial satélite'.contains(_searchQuery))
                  _buildProjectCard(
                    title: 'Residencial Satélite',
                    statusBadge: 'Normal',
                    statusBadgeBg: Colors.green.withOpacity(0.1),
                    statusBadgeColor: Colors.green,
                    subtitle: 'Satélite · 2 contratistas · 11 partidas',
                    progressValue: 0.45,
                    progressColor: Colors.green,
                    bottomLeftText: '\$850K',
                    bottomCenterBadge: 'Aprobado',
                    bottomCenterBadgeBg: Colors.green.withOpacity(0.1),
                    bottomCenterBadgeColor: Colors.green,
                    bottomRightText: 'En tiempo',
                  ),
                if ('residencial satélite'.contains(_searchQuery))
                  const SizedBox(height: 16),
                if ('plaza comercial cumbres'.contains(_searchQuery))
                  _buildProjectCard(
                    title: 'Plaza Comercial Cumbres',
                    statusBadge: 'Revisión',
                    statusBadgeBg: Colors.orange.withOpacity(0.1),
                    statusBadgeColor: Colors.orange,
                    subtitle: 'Monterrey · 4 contratistas · 24 partidas',
                    progressValue: 0.6,
                    progressColor: Colors.orange,
                    bottomLeftText: '\$2.1M',
                    bottomCenterBadge: 'Cotizando',
                    bottomCenterBadgeBg: Colors.blue.withOpacity(0.1),
                    bottomCenterBadgeColor: Colors.blue,
                    bottomRightText: 'Desviación +5%',
                  ),
                if ('plaza comercial cumbres'.contains(_searchQuery))
                  const SizedBox(height: 16),
                if ('remodelación hospital sur'.contains(_searchQuery))
                  _buildProjectCard(
                    title: 'Remodelación Hospital Sur',
                    statusBadge: 'Normal',
                    statusBadgeBg: Colors.green.withOpacity(0.1),
                    statusBadgeColor: Colors.green,
                    subtitle: 'CDMX Sur · 1 contratista · 5 partidas',
                    progressValue: 0.15,
                    progressColor: Colors.green,
                    bottomLeftText: '\$320K',
                    bottomCenterBadge: 'Planeación',
                    bottomCenterBadgeBg: Colors.grey.withOpacity(0.1),
                    bottomCenterBadgeColor: Colors.grey[700]!,
                    bottomRightText: 'En tiempo',
                  ),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProjectCard({
    required String title,
    required String statusBadge,
    required Color statusBadgeBg,
    required Color statusBadgeColor,
    required String subtitle,
    required double progressValue,
    required Color progressColor,
    required String bottomLeftText,
    required String bottomCenterBadge,
    required Color bottomCenterBadgeBg,
    required Color bottomCenterBadgeColor,
    required String bottomRightText,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: statusBadgeBg,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(statusBadge, style: TextStyle(color: statusBadgeColor, fontSize: 12, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)),
          const SizedBox(height: 16),
          LinearProgressIndicator(
            value: progressValue,
            backgroundColor: Colors.grey[200],
            color: progressColor,
            minHeight: 6,
            borderRadius: BorderRadius.circular(4),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(bottomLeftText, style: const TextStyle(color: Colors.grey, fontSize: 13, fontWeight: FontWeight.bold)),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: bottomCenterBadgeBg,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(bottomCenterBadge, style: TextStyle(color: bottomCenterBadgeColor, fontSize: 12, fontWeight: FontWeight.bold)),
              ),
              Text(bottomRightText, style: const TextStyle(color: Colors.grey, fontSize: 13)),
            ],
          ),
        ],
      ),
    );
  }
}
